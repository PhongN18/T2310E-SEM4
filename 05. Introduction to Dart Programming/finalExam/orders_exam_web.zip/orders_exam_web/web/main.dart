\
import 'dart:convert';
import 'dart:html';
import '../lib/order.dart';

/// The given JSON string from the exam statement
const String initialJson =
    '[{"Item": "A1000","ItemName": "Iphone 15","Price": 1200,"Currency":"USD","Quantity":1},'
    '{"Item": "A1001","ItemName": "Iphone 16","Price":1500,"Currency": "USD","Quantity":1}]';

final List<Order> _orders = <Order>[];

void main() {
  // 1) Parse JSON → populate _orders
  final List<dynamic> decoded = jsonDecode(initialJson) as List<dynamic>;
  _orders.clear();
  _orders.addAll(decoded.map((e) => Order.fromJson(e as Map<String, dynamic>)));

  // 2) Hook up UI
  _renderTable(_orders);

  // Search
  final InputElement search = querySelector('#search') as InputElement;
  search.onInput.listen((_) {
    final query = search.value?.trim().toLowerCase() ?? '';
    if (query.isEmpty) {
      _renderTable(_orders);
    } else {
      final filtered = _orders.where((o) => o.itemName.toLowerCase().contains(query)).toList();
      _renderTable(filtered);
    }
  });

  // Insert order
  final FormElement form = querySelector('#orderForm') as FormElement;
  final Element msg = querySelector('#formMsg')!;
  form.onSubmit.listen((e) {
    e.preventDefault();

    final item = (querySelector('#fItem') as InputElement).value!.trim();
    final itemName = (querySelector('#fItemName') as InputElement).value!.trim();
    final priceStr = (querySelector('#fPrice') as InputElement).value!.trim();
    final currency = (querySelector('#fCurrency') as InputElement).value!.trim().toUpperCase();
    final qtyStr = (querySelector('#fQuantity') as InputElement).value!.trim();

    if (item.isEmpty || itemName.isEmpty || priceStr.isEmpty || currency.isEmpty || qtyStr.isEmpty) {
      msg.text = 'Please fill all fields correctly.';
      return;
    }

    final price = num.parse(priceStr);
    final qty = int.parse(qtyStr);

    // Avoid duplicate Item codes
    final exists = _orders.any((o) => o.item.toLowerCase() == item.toLowerCase());
    if (exists) {
      msg.text = 'Item "$item" already exists.';
      return;
    }

    final newOrder = Order(
      item: item,
      itemName: itemName,
      price: price,
      currency: currency,
      quantity: qty,
    );

    _orders.add(newOrder);
    // Re-render with potential active filter
    final currentQuery = (querySelector('#search') as InputElement).value?.trim().toLowerCase() ?? '';
    if (currentQuery.isEmpty) {
      _renderTable(_orders);
    } else {
      final filtered = _orders.where((o) => o.itemName.toLowerCase().contains(currentQuery)).toList();
      _renderTable(filtered);
    }

    form.reset();
    msg.text = 'Inserted order ${newOrder.item}.';
  });

  // Download current orders as order.json (simulates "insert into order.json")
  final ButtonElement downloadBtn = querySelector('#downloadBtn') as ButtonElement;
  downloadBtn.onClick.listen((_) {
    final jsonList = _orders.map((o) => o.toJson()).toList();
    final pretty = const JsonEncoder.withIndent('  ').convert(jsonList);
    _downloadText(pretty, filename: 'order.json');
  });
}

void _renderTable(List<Order> list) {
  final tbody = querySelector('#ordersBody') as TableSectionElement;
  tbody.children.clear();

  for (final o in list) {
    final tr = TableRowElement();
    tr.children = <TableCellElement>[
      TableCellElement()..text = o.item,
      TableCellElement()..text = o.itemName,
      TableCellElement()..text = o.price.toString(),
      TableCellElement()..text = o.currency,
      TableCellElement()..text = o.quantity.toString(),
    ];
    tbody.children.add(tr);
  }

  // If empty, show a friendly row
  if (list.isEmpty) {
    final tr = TableRowElement();
    final td = TableCellElement()
      ..colSpan = 5
      ..text = 'No orders match your search.';
    tr.children.add(td);
    tbody.children.add(tr);
  }
}

void _downloadText(String content, {required String filename}) {
  final bytes = Utf8Encoder().convert(content);
  final blob = Blob([bytes], 'application/json');
  final url = Url.createObjectUrlFromBlob(blob);
  final anchor = AnchorElement(href: url)
    ..setAttribute('download', filename)
    ..click();
  Url.revokeObjectUrl(url);
}
