class Order {
  final String item;       // e.g., A1000
  final String itemName;   // e.g., Iphone 15
  final num price;         // allow int or double
  final String currency;   // e.g., USD
  final int quantity;      // e.g., 1

  Order({
    required this.item,
    required this.itemName,
    required this.price,
    required this.currency,
    required this.quantity,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        item: json['Item'] as String,
        itemName: json['ItemName'] as String,
        price: json['Price'] as num,
        currency: json['Currency'] as String,
        quantity: json['Quantity'] as int,
      );

  Map<String, dynamic> toJson() => {
        'Item': item,
        'ItemName': itemName,
        'Price': price,
        'Currency': currency,
        'Quantity': quantity,
      };
}
